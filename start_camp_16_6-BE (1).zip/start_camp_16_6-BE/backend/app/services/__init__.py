"""Application services for LocalHub."""
