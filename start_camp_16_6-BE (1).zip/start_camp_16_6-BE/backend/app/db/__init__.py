"""Database helpers for LocalHub."""
