"""Database models for LocalHub."""
