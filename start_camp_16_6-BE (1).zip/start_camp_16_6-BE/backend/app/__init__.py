"""LocalHub backend application package."""
