"""Pydantic schemas for LocalHub."""
